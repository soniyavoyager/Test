	<?php


 if(isset($_GET["p"]))
	{
	    
		if($_GET["p"]=="login")
		{
		    
			login();
			
		}
		else
if($_GET["p"]=="change_password")
		{
		    
			change_password();
			
		}
		
			else
if($_GET["p"]=="Plot")
		{
		    
			Plot();
			
		}
		
			else
if($_GET["p"]=="jobcard_Residential")
		{
		    
			jobcard_Residential();
			
		}
		
					else
if($_GET["p"]=="jobcard_with_company")
	
		{
		    
			jobcard_with_company();
			
		}
	
		else
if($_GET["p"]=="worker_list")
		{
		    
			worker_list();
			
		}
		
			else
if($_GET["p"]=="materials_list")
		{
		   
		 // echo("hello");
		   	materials_list();
			
		}
				else
if($_GET["p"]=="materials_unit_with_id")
		{
		   
		  // echo("hello");
		    
			material_unit_with_id();
			
		}	
		else
if($_GET["p"]=="Jobcardsubmit")
		{
		    
			Jobcardsubmit();
			
		}
		
				else
if($_GET["p"]=="Jobcardlist")
		{
		    
			Jobcardlist();
			
		}
			else
if($_GET["p"]=="meaterial_req_list")
		{
		    
			meaterial_req_list();
			
		}
		
			else
if($_GET["p"]=="meaterial_list_id")
		{
		    
			meaterial_list_id();
			
		}		
		
		
		
			else
if($_GET["p"]=="meaterial_det_add")
		{
		    
			meaterial_det_add();
			
		}
		
		
			else
if($_GET["p"]=="meaterial_search")
		{
		    
			meaterial_req_search();
			
		}
		
			else
if($_GET["p"]=="job_card_completed")
		{
		    
			job_card_completed();
			
		}
		
			else
if($_GET["p"]=="job_card_completed_list")
		{
		    
			job_card_completed_list();
			
		}
		
	
					else
if($_GET["p"]=="job_card_datails")
		{
		    
			job_card_datails();
			
		}		
		
				else
if($_GET["p"]=="Create_folder")
		{
		   Create_folder();
			
		}		
			
	
		else
if($_GET["p"]=="job_card_folder_list")
		{
		    
			job_card_folder_list();
			
		}	
		
		else
if($_GET["p"]=="job_card_root_imgs")
		{
		    
			job_card_root_imgs();
			
		}
		
				else
if($_GET["p"]=="job_card_folder_imgs")
		{
		    
			job_card_folder_imgs();
			
		}		
					else
if($_GET["p"]=="category_merterial_request")
		{
		    
			category_merterial_request();
			
		}	
						else
if($_GET["p"]=="category_card_id_request")
		{
		    
			category_card_id_request();
			
		}	
								else
if($_GET["p"]=="work_schedule_request")
		{
		    
			work_shedule_request();
			
		}	
					
		else
if($_GET["p"]=="work_shedule_employees")
		{
		  	work_shedule_employees();
			
		}			
					
		else
if($_GET["p"]=="work_schedule_list")
		{
		    
			work_shedule_list();
			
		}			
	else
if($_GET["p"]=="work_schedule_details")
		{
		  	work_shedule_details();
		  	}		
		  		else
if($_GET["p"]=="schedule_emoployee_list")
		{
		  	shedule_emoployee_list();
		  	}
		  	
			else
if($_GET["p"]=="schedule_emoployees_jobcard_list")
		{
		  	shedule_emoployees_jobcard_list();
		  	}
		  	  
		  	  else
if($_GET["p"]=="remove_schedule")
		{
		    
			remove_schedule();
			
		}	
		  	  else
if($_GET["p"]=="update_schedule_details")
		{
		    
			update_schedule_details();
			
		}	
		  		  
		  
			  	  else
if($_GET["p"]=="shedule_emoployee_date_list")
		{
		    
			shedule_emoployee_date_list();
			
		}	  	
				  	  else
if($_GET["p"]=="update_employee_schedule_details")
		{
		    
			update_employee_schedule_details();
			
		}	
		
					  	  else
if($_GET["p"]=="employees")
		{
		    
			employees();
			
		}
	
						  	  else
if($_GET["p"]=="work_schedule_list_today")
		{
		    
			work_schedule_list_today();
			
		}
							  	  else
if($_GET["p"]=="update_schedule_single")
		{
		    
			update_schedule_single();
			
		}
	}
	
	
	
	

function login()
	{
	    
	    
 require_once 'db.php';

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    
	    
       $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
	
		//0= owner  1= company 2= ind mechanic
		
		if(isset($event_json['username']) && isset($event_json['password']) )
		{
			$email=htmlspecialchars(strip_tags($event_json['username'] , ENT_QUOTES));
			$password=strip_tags($event_json['password']);
		
			//	$passwordecrpty = ($password);
				$passwordecrpty =  md5($password);
				
			$log_in="select * from staffs where email='".$email."' and password='".$passwordecrpty."' ";

	
			$log_in_rs=mysqli_query($conn,$log_in);
			
			if(mysqli_num_rows($log_in_rs))
			{
			    
			     while($row2 = mysqli_fetch_array($log_in_rs))
  {
   $id=$row2['id'];
  $first_name=$row2['first_name'];
  $last_name=$row2['last_name'];
  $email=$row2['email'];  
  $phone=$row2['phone'];
 
  }
		$output["id"] = $id;
		$output["first_name"] = $first_name;
        $output["last_name"] = $last_name;
        $output["email"] = $email;
        $output["phone"] = $phone;	    
			    
			//	$array_out = array();
				 $array_out =$output;
					
					$value= "login success";
				$output=array( "code" => "200","value" => $array_out,"msg"=>$value);
				print_r(json_encode($output, true));
			}	
			else
			{
			    
			    $array_out1="Error in login";
			    
    			$array_out = array();
    					
        		 $array_out[] = array(
        			"response" =>"Error in login");
        		
        		$output=array( "code" => "201", "msg" => $array_out1);
        		print_r(json_encode($output, true));
			}
		}
		else
		{
			$array_out = array();
					
			 $array_out[] = 
				array(
				"response" =>"Json Parem are missing19");
			
			$output=array( "code" => "201", "msg" => $array_out);
			print_r(json_encode($output, true));
		}

}

function change_password()
	{
	    
	    
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    
	    
       $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
	//print_r($event_json);
		//0= owner  1= company 2= ind mechanic
		
		if(isset($event_json['current_pass']) && isset($event_json['new_pass']) )
		{
		
		
			$current_pass=strip_tags($event_json['current_pass']);
			$new_pass=strip_tags($event_json['new_pass']);
			$id=strip_tags($event_json['id']);
			
				$passwordecrpty =  md5($current_pass);
				$new_pass_ecrpty =  md5($new_pass);
				
			$log_in="select * from staffs where id='".$id."' AND password= '".$passwordecrpty."'";


			$log_in_rs=mysqli_query($conn,$log_in);
			
			if(mysqli_num_rows($log_in_rs))
			{
			   	$password_ch="UPDATE `staffs` SET `password`='$new_pass_ecrpty' WHERE  id='".$id."'";
			   	
			   
            	$log_in_ch=mysqli_query($conn,$password_ch); 
			   	$value= "Password update sucessfully";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));
			}	
			else
			{
			    
			    $value= "Error in Change Password";
        		$output=array( "code" => "201", "msg" => $value);
        		print_r(json_encode($output, true));
			}
			
			
			
		}
		else
		{
			$array_out = array();
					
			 $array_out[] = 
				array(
				"response" =>"Json Parem are missing19");
			
			$output=array( "code" => "201", "msg" => $array_out);
			print_r(json_encode($output, true));
		}

}


function jobcard_Residential()
	{
	  
		    
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    	$Site="SELECT * FROM `Site`";
            $Site_det=mysqli_query($conn,$Site);
			$response = array();
        while( $row = mysqli_fetch_assoc($Site_det) ){
            array_push($response, 
            array(
                'Site_id'=>$row['id'], 
                'Site_name'=>$row['name'], 
                
                ) 
            );
        }
     
			   	$category="SELECT * FROM `job_types`";
			   	
			   	$category_det=mysqli_query($conn,$category);
				
					 $response_category = array();
        while( $row1 = mysqli_fetch_assoc($category_det) ){
            array_push($response_category, 
            array(
                'category_id'=>$row1['id'], 
                'category_name'=>$row1['name'], 
                
                ) 
            );
        }
				
			
				$output=array( "code" => "200","site"=>$response,"category"=>$response_category);
				print_r(json_encode($output, true));  
	    
	}
	
	
	
function employees()
	{
	  
		    
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  		
			$Site="SELECT * FROM `employees`";

	
			$Site_det=mysqli_query($conn,$Site);
			
			
			 $response = array();
        while( $row = mysqli_fetch_assoc($Site_det) ){
            array_push($response, 
            array(
                'workers_id'=>$row['id'], 
                'workers_name'=>$row['name'], 
                
                ) 
            );
        }
               $output=array( "code" => "200","workers"=>$response);
				print_r(json_encode($output, true));  
	    
	}	
	
	
	

function Plot()
	{
	  
		    
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  		
			$Site="SELECT * FROM `Plot`";

	
			$Site_det=mysqli_query($conn,$Site);
			
			
			 $response = array();
        while( $row = mysqli_fetch_assoc($Site_det) ){
            array_push($response, 
            array(
                'Plot_id'=>$row['id'], 
                'Plot_name'=>$row['name'], 
                
                ) 
            );
        }
               $output=array( "code" => "200","Plot"=>$response);
				print_r(json_encode($output, true));  
	    
	}





function meaterial_list_id()
	{
	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	      $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
		   	$meterial_rate="SELECT sum(`met_rate`) as total FROM `meterial_req_details` WHERE `met_d_id`='".$id."' ";
        $meterial_rate_det=mysqli_query($conn,$meterial_rate);
	
       $row2 = mysqli_fetch_assoc($meterial_rate_det);
        $rate=$row2['total']; 
		    
		    
			$Site="SELECT * FROM `meterial_req_details` where met_d_id='".$id."'";
            $Site_det=mysqli_query($conn,$Site);
            
            
            	 $response = array();
             while( $row = mysqli_fetch_assoc($Site_det) ){
            array_push($response, 
            array(
                'Id'=>$row['m_r_did'], 
                'meterial_name'=>$row['meterial_name'],
                'unit_name'=>$row['unit_name'],
                'qty'=>$row['qty'], 
                 'total'=>number_format($row[met_rate],3),
                
                ) 
            );
        }
			
			
			}  
				$output=array( "code" => "200","meterial_req_details"=>$response);
				print_r(json_encode($output, true));  
			}	
			


function jobcard_with_company()
	{
	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
			$Site="SELECT * FROM `Site` where plot='".$id."'";
            $Site_det=mysqli_query($conn,$Site);
			$response = array();
        while( $row = mysqli_fetch_assoc($Site_det) ){
            array_push($response, 
            array(
                'Site_id'=>$row['id'], 
                'Site_name'=>$row['name'], 
                
                ) 
            );
        }
			
			
			  	$category="SELECT * FROM `job_types`";
			   	
			   	$category_det=mysqli_query($conn,$category);
				
					 $response_category = array();
        while( $row1 = mysqli_fetch_assoc($category_det) ){
            array_push($response_category, 
            array(
                'category_id'=>$row1['id'], 
                'category_name'=>$row1['name'], 
                
                ) 
            );
        }
				$output=array( "code" => "200","site"=>$response,"category"=>$response_category);
				print_r(json_encode($output, true));  
			}	
			
			
			else
		{
			$array_out = array();
					
			 $array_out[] = 
				array(
				"response" =>"Json Parem are missing");
			
			$output=array( "code" => "201", "msg" => $array_out);
			print_r(json_encode($output, true));
		}	
		
	}
	
	function worker_list()	
	{
   require_once 'db.php';
   if ($conn->connect_error) 
    {
    die("Connection failed: " . $conn->connect_error);
     }  
	 $workers="SELECT * FROM `employees`";
     $workers_det=mysqli_query($conn,$workers);
     $response = array();
	 
        while( $row = mysqli_fetch_assoc($workers_det))
        {
            array_push($response, 
            array(
                'workers_id'=>$row['id'], 
                'workers_name'=>$row['name'], 
                
                ) 
            );
        }
        
        	$output=array( "code" => "200","workers"=>$response);
			print_r(json_encode($output, true));  
	
	}


function materials_list()	
	{
	    

   require_once 'db.php';
   if ($conn->connect_error) 
    {
    die("Connection failed: " . $conn->connect_error);
     }  
	 
	 
	 $materials="SELECT * FROM `materials`";
     $materials_det=mysqli_query($conn,$materials);
     
    
	 $response = array();
	 
        while( $row = mysqli_fetch_assoc($materials_det))
        {
           
      $categoryid=$row['category'];
	  
	    	$Product_category="select * from  Product_category where id='".$categoryid."' ";
	        $Product_category1=mysqli_query($conn,$Product_category);
			 while($row2 = mysqli_fetch_assoc($Product_category1))
  {
   
    $product_name=$row2['product_name']; 
 }


  $Segmentid=$row['Segment'];
	  
	    	$Product_Segment="select * from  Segment where id='".$Segmentid."' ";
	        $Product_Segment1=mysqli_query($conn,$Product_Segment);
		  while($row3 = mysqli_fetch_assoc($Product_Segment1))
  {
   
    $seg_name=$row3['seg_name']; 
    
   
  }
	$log_in="select * from unit where id='".$row['unit']."' ";

	$log_in_rs=mysqli_query($conn,$log_in);
	 while($row2 = mysqli_fetch_array($log_in_rs))
  {
    $name=$row2['name']; 
     array_push($response, 
            array(
                'materials_id'=>$row['id'], 
                'materials_name'=>$row['name'], 
                'materials_unit'=>$name,
                'materials_unit_id'=>$row['unit'],
                'materials_product_c'=>$product_name,
                'materials_product_c_id'=>$categoryid,
                'materials_seg'=>$seg_name,
                'materials_seg_id'=>$Segmentid,
                'materials_code'=>$row['code'],
                'materials_qty'=>$row['Quantity'],
                'materials_Rate'=>$row['rate'], 
                
                ) 
            );
  }
        }
    
    	$output=array( "code" => "200","materials"=>$response);
		print_r(json_encode($output, true));  
	
	}
	
	
function Jobcardsubmit()
	{
 require_once 'db.php';
	    
$json = file_get_contents('php://input');
$data = json_decode($json);	   

$date=$data->date;
$comp_or_resi=$data->comp_or_resi;
$plot=$data->plot;
$site=$data->site;
$location=$data->location;
$work_description=$data->work_description;

$product_data=array();
$product_data=$data->{categories};



    $query = "SELECT job_id from  jobcard_master order by id DESC LIMIT 1";
    $stmt = $conn->query($query);
    if(mysqli_num_rows($stmt) > 0) {
        if ($row = mysqli_fetch_assoc($stmt)) {
            $value2 = $row['job_id'];
            $value2 = substr($value2, 6, 9);//separating numeric part
            $value2 = $value2 + 1;//Incrementing numeric part
            $value2 = "JBC21:" . sprintf('%03s', $value2);//concatenating incremented value
            $value = $value2; 
        }
    } 
    else {
        $value2 = "JBC21:001";
        $value = $value2;
    }


  if($num_rows>0)
  {
   
    echo "exists";
 
   
  }
  
  else
  {
      $status='';
      $job_completed_date='';
    $sql="INSERT INTO `jobcard_master`(`job_id`, `card_date`, `comp_or_resi`, `plot`, `site`, `location`, `work_description`,`status`,`job_completed_date`)
    VALUES('$value','$date','$comp_or_resi','$plot','$site','$location','$work_description','$status','$job_completed_date') ";
  
  if( mysqli_query($conn,$sql))
  {
      for ($i=0; $i < count($product_data); $i++) { 
     
       $cat_id=$product_data[$i];
      
       $sql2="INSERT INTO `jobcard_det`(`job_id`, `categories`) VALUES ('$value','$cat_id') ";

       mysqli_query($conn,$sql2); }
      
        $response= "success"; 
        $output=array( "code" => "200","msg"=>$response);
		print_r(json_encode($output, true));  
	    
	}	
	
	 else
  {
      
        $response= "fail"; 
        $output=array( "code" => "200","msg"=>$response);
        print_r(json_encode($output, true));  
  }
   
}
	}





function meaterial_det_add()
	{
	    

 require_once 'db.php';
	    
$json = file_get_contents('php://input');
$data = json_decode($json);	   

$date=date("Y-m-d");
$jobcard_id=$data->jobcard_id;
$category_id=$data->category_id;

$meterial_data=array();
 $meterial_data=$data->{materials};


  $query = "SELECT met_id from meterial_req_master order by `id` DESC LIMIT 1";
    $stmt = $conn->query($query);
    
   
    if(mysqli_num_rows($stmt) > 0) {
        if ($row = mysqli_fetch_assoc($stmt)) {
            $value2 = $row['met_id'];
            $value2 = substr($value2, 7, 10);//separating numeric part
            $value2 = $value2 + 1;//Incrementing numeric part
            $value2 = "METR21:" . sprintf('%03s', $value2);//concatenating incremented value
            $value = $value2; 
        }
    } 
    else {
        $value2 = "METR21:001";
        $value = $value2;
    }
 

  if($num_rows>0)
  {
   echo "exists";
  }
  
  else
  {
      
 $status = "Pending";
if($jobcard_id!='')
{
    $sql="INSERT INTO `meterial_req_master`(`met_id`, `m_c_date`, `status`,`jobcard_id`,`Category_id`)
    VALUES('$value','$date','$status','$jobcard_id','$category_id') ";

}
    
  if( mysqli_query($conn,$sql))
  {
     for ($i=0; $i < count($meterial_data); $i++)
      { 
     
       $meterial=$meterial_data[$i]->material_id;
       
       	$meterial_rate="SELECT * FROM `materials` where id='$meterial'";
        $meterial_rate_det=mysqli_query($conn,$meterial_rate);
	
       $row2 = mysqli_fetch_assoc($meterial_rate_det);
        $rate=$row2['rate'];
        
       
       $material_namenew=$meterial_data[$i]->material_name;
	   $unit=$meterial_data[$i]->unit_id;
	    $unit_name=$meterial_data[$i]->unit_name;
	    $qty=$meterial_data[$i]->quantity;
          $met_rate=number_format(($rate*$qty),3);
		  
       $sql2="INSERT INTO `meterial_req_details`( `met_d_id`, `meterial`, `meterial_name`, `unit`, `unit_name`, `qty`, `met_rate`) VALUES 
       ('$value','$meterial','$material_namenew','$unit','$unit_name','$qty','$met_rate') ";

      mysqli_query($conn,$sql2); }
      
        $response= "Material Created Successfully"; 
        $output=array( "code" => "200","msg"=>$response);
		print_r(json_encode($output, true));  
	    
	}	
	
	 else
  {
      
        $response= "fail"; 
        $output=array( "code" => "200","msg"=>$response);
        print_r(json_encode($output, true));  
  }
   
}
	}






function material_unit_with_id()
	{
	  
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	      $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
			$id=strip_tags($event_json['id']);
			$materials="SELECT * FROM `materials` where id='$id'";
            $materials=mysqli_query($conn,$materials);
			while($row2 = mysqli_fetch_array($materials))
  {
    $unit=$row2['unit']; 
  }	
	$log_in="select * from unit where id='".$unit."' ";

	$log_in_rs=mysqli_query($conn,$log_in);
	        
	     
			  while($row2 = mysqli_fetch_array($log_in_rs))
  {
    $name=$row2['name']; 
  }	
		$response = array();
             array_push($response, 
            array(
                'unit_id'=>$unit,
                'unit_name'=>$name,)); 
           	$output=array( "code" => "200","materials_unit"=>$response);
			print_r(json_encode($output, true));  
	    
	}
	}
	
function meaterial_req_list()
	{
	  
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
  
}  
        $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['jobcard_id']))
		{
			$id=strip_tags($event_json['jobcard_id']);
	   	    $meterial_req_master="SELECT * FROM `meterial_req_master`  where jobcard_id	='$id' ORDER BY `meterial_req_master`.`id` DESC";
            $meterial_req_master=mysqli_query($conn,$meterial_req_master);
			 $response = array();
        while( $row = mysqli_fetch_assoc($meterial_req_master)){
            $met_id =$row['met_id'];
            
           
		   	$meterial_rate="SELECT sum(`met_rate`) as total FROM `meterial_req_details` WHERE `met_d_id`='".$met_id."'";
        $meterial_rate_det=mysqli_query($conn,$meterial_rate);
	
       $row2 = mysqli_fetch_assoc($meterial_rate_det);
        $rate=$row2['total']; 
            
             $Category_id =$row['Category_id'];
             
           
             
             $Product_category="select * from  job_types where id='".$Category_id."' ";
	    	  $Product_category1=mysqli_query($conn,$Product_category);
			 while($row5 = mysqli_fetch_assoc($Product_category1))
  {
   $product_id=$row5['id']; 
    $product_name=$row5['name']; 
 }
  
            
            array_push($response, 
            array(
                'met_id'=>$row['met_id'], 
                'm_c_date'=>$row['m_c_date'], 
                'category_name'=>$product_name,
                'total'=>number_format($rate,3),
                'status'=>$row['status'], 
                
                )); 
        }
		
				$output=array( "code" => "200","meterial_req_list"=>$response);
				print_r(json_encode($output, true));
		}
	}


function Jobcardlist()
	{
	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    	$jobcard_master="SELECT * FROM `jobcard_master` where status!='Completed' ORDER BY `jobcard_master`.`id` DESC  ";
            $jobcard_master_det=mysqli_query($conn,$jobcard_master);
			 $response = array();
        while( $row = mysqli_fetch_assoc($jobcard_master_det)){
            
            $job_id =$row['job_id'];
             $site =$row['site'];
             
             $Site="SELECT * FROM `Site` where id='".$site."'";
            // echo($Site);
            $Site_det=mysqli_query($conn,$Site);
		   $row3 = mysqli_fetch_assoc($Site_det);
            
                $Site_id=$row3['id']; 
                $Site_name=$row3['name']; 
            
              
            array_push($response, 
            array(
                'job_id'=>$row['job_id'], 
                'card_date'=>$row['card_date'], 
                
                  'Site_name'=>$Site_name, 
                'work_description'=>$row['work_description'], 
                
                ));  }
      
				$output=array( "code" => "200","jobcard_master"=>$response);
				print_r(json_encode($output, true));  
	    
	}	
	
	
function meaterial_req_search()
	{
	  
 require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
  
}  
        $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['search_text']))
		{
		   $search_text=strip_tags($event_json['search_text']);
	   	   $materials = "SELECT * FROM materials  WHERE name LIKE '%$search_text%'";
	   	   $materials_det=mysqli_query($conn,$materials);
           $response = array();
	 
        while( $row = mysqli_fetch_assoc($materials_det))
        {
           
      $categoryid=$row['category'];
	  
	    	$Product_category="select * from  Product_category where id='".$categoryid."' ";
	        $Product_category1=mysqli_query($conn,$Product_category);
			while($row2 = mysqli_fetch_assoc($Product_category1))
  {
   
    $product_name=$row2['product_name']; 
 }


            $Segmentid=$row['Segment'];
            $Product_Segment="select * from  Segment where id='".$Segmentid."' ";
	        $Product_Segment1=mysqli_query($conn,$Product_Segment);
		  while($row3 = mysqli_fetch_assoc($Product_Segment1))
  {
   $seg_name=$row3['seg_name']; 
  }
	$log_in="select * from unit where id='".$row['unit']."' ";

	$log_in_rs=mysqli_query($conn,$log_in);
	 while($row2 = mysqli_fetch_array($log_in_rs))
  {
    $name=$row2['name']; 
     array_push($response, 
            array(
                'materials_id'=>$row['id'], 
                'materials_name'=>$row['name'], 
                'materials_unit'=>$name,
                'materials_unit_id'=>$row['unit'],
                'materials_product_c'=>$product_name,
                'materials_product_c_id'=>$categoryid,
                'materials_seg'=>$seg_name,
                'materials_seg_id'=>$Segmentid,
                'materials_code'=>$row['code'],
                'materials_qty'=>$row['Quantity'],
                'materials_Rate'=>$row['rate'], 
                
                ) 
            );
  }
        }
    
    	$output=array( "code" => "200","materials"=>$response);
		print_r(json_encode($output, true));  
	
	}	
	
	
	}	
	
	
	
	
	function job_card_completed()
	{
	  
 require_once 'db.php';

  if ($conn->connect_error) 
  {
  die("Connection failed: " . $conn->connect_error);
   }  
	    
	      $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
			
			$status='Completed';
			$completed_date=date("d/m/Y");
			
			$jobcard_master="UPDATE `jobcard_master` SET `status`='$status',`job_completed_date`='$completed_date' WHERE  job_id='".$id."'";
			
            if(mysqli_query($conn,$jobcard_master))
			{
			$response='Jobcard Completed Sucessfully';
			
			$output=array( "code" => "200","msg"=>$response);
				print_r(json_encode($output, true));  
			
			
			}
			
		
			else
			{
			$response='Fail';
			$output=array( "code" => "200","msg"=>$response);
				print_r(json_encode($output, true));  
			}
			
			  
				
			}
	}
	
function job_card_completed_list()
	{
	  

	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    $status='Completed';
			
			 $response = array();
			$jobcard_master="select * from jobcard_master  WHERE  status='".$status."' ORDER BY `jobcard_master`.`id` DESC ";
		
	$log_in_rs=mysqli_query($conn,$jobcard_master);
	 while($row = mysqli_fetch_array($log_in_rs))
  {
     
            array_push($response, 
            array(
                'job_id'=>$row['job_id'], 
                'card_created_date'=>$row['card_date'], 
				'card_end_date'=>$row['job_completed_date'], 
                'work_description'=>$row['work_description'], 
                'status'=>$row['status'], 
                )); 
              
        
        }
      
				$output=array( "code" => "200","job_card_completed_list"=>$response);
				print_r(json_encode($output, true));    
				
				
	
	}
	
	function Create_folder()
	{
	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	      $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
			
			$foldername=strip_tags($event_json['jobcard_img_folders']);
				$Category_id=strip_tags($event_json['Category_id']);
			
			$jobcard_folder="select * from jobcard_img_folders  WHERE  folder_name='".$foldername."' and jobcard_id='".$id."'";
			 $jobcard_folder_rs=mysqli_query($conn,$jobcard_folder);
			$row = mysqli_fetch_array($jobcard_folder_rs);
			
		//	echo($row);
	
			if($row)
			{
			$response='Jobcard Folder is exsist';
			
			$output=array( "code" => "201","msg"=>$response);
			print_r(json_encode($output, true));  
			}
			else{
			
			$jobcard_folder_insert="INSERT INTO `jobcard_img_folders`(`jobcard_id`, `folder_name`,`Category_id`) VALUES ('$id','$foldername','$Category_id')";
			
		  if(mysqli_query($conn,$jobcard_folder_insert))
			{
			$response='Jobcard Folder Created Sucessfully';
		    $output=array( "code" => "200","msg"=>$response);
			print_r(json_encode($output, true));  
		}
		   else
			{
			$response='Jobcard Folder Created Fail';
			$output=array( "code" => "200","msg"=>$response);
			print_r(json_encode($output, true));  
			}
		    } 
		    }	
			}
			
			
function job_card_folder_list()
	{  
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}    
        $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
			 $id=strip_tags($event_json['id']);
			 $response = array();
			 $job_card_folder_list="select * from jobcard_img_folders  WHERE  jobcard_id='".$id."' ORDER BY `jobcard_img_folders`.`f_id` ASC";
		
	$job_card_folder_list_rs=mysqli_query($conn,$job_card_folder_list);
	while($row = mysqli_fetch_array($job_card_folder_list_rs))
              {
                $Category_id=$row['Category_id'];  
                
                	$Product_category="select * from  job_types where id='".$Category_id."' ";
	    $Product_category1=mysqli_query($conn,$Product_category);
			 while($row5 = mysqli_fetch_assoc($Product_category1))
  {
   $product_id=$row5['id']; 
    $product_name=$row5['name']; 
 }
  
                  
             array_push($response, 
            array(
                //'job_id'=>$row['jobcard_id'], 
                'folder_name'=>$row['folder_name'],
                 'category_name'=>$product_name,
                )); 
               }
      
		$output=array( "code" => "200","job_card_folder_list"=>$response);
		print_r(json_encode($output, true));    
	}
	}	
			
		
		
function job_card_root_imgs()
	{  
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
			 $id=strip_tags($event_json['id']);
			
			 $response = array();
		
		$job_card_root_imgs="SELECT * FROM work_shedule_master INNER JOIN work_shedule_detail ON work_shedule_detail.w_s_m_id = work_shedule_master.id
        where work_shedule_master.worker_id='".$id."'";
        $job_card_root_imgs_rs=mysqli_query($conn,$job_card_root_imgs);
        
        
	while($row = mysqli_fetch_array($job_card_root_imgs_rs))
         {
       array_push($response, 
            array(
                'job_id'=>$row['jobcard_id'], 
                 'job_id'=>$row['date'], 
                  'job_id'=>$row['over_time1'], 
                   'job_id'=>$row['over_time2'], 
                    'job_id'=>$row['jobcard_id'], 
                
                )); 
       }	$output=array( "code" => "200","job_card_root_images_list"=>$response);
				print_r(json_encode($output, true)); 
				
	}
	}	
		


function job_card_folder_imgs()
	{ 
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		$id=strip_tags($event_json['id']);
		$fdrl=strip_tags($event_json['folder_name']);
		$response = array();
	$job_card_folder_imgs="SELECT * FROM job_card_img_mst INNER JOIN job_card_img_det ON job_card_img_mst.id = job_card_img_det.jc_im_id where job_card_img_mst.folder_name='".$fdrl."' and job_card_img_mst.jobcard_id='".$id."'";
   	$job_card_folder_imgs_rs=mysqli_query($conn,$job_card_folder_imgs);
	
	
	while($row = mysqli_fetch_array($job_card_folder_imgs_rs))
  {
       array_push($response, 
           $row['image']);   }
      
				$output=array( "code" => "200","job_card_folder_imgs"=>$response);
				print_r(json_encode($output, true));    
	}
	}
	
	
	
	
	
function job_card_datails()
	{
	  
 require_once 'db.php';

  if ($conn->connect_error) 
  {
  die("Connection failed: " . $conn->connect_error);
   }  
	    
	      $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
			$status_f='Completed';
			$jobcard_master="select * from jobcard_master  WHERE  job_id='".$id."' and status='".$status_f."' ";
		    $jobcard_master_rs=mysqli_query($conn,$jobcard_master);
	        $row = mysqli_fetch_assoc($jobcard_master_rs);
			 $plot=$row['plot'];
			 $site=$row['site'];
			 $location=$row['location'];
			  $job_id=$row['job_id'];
			$job_completed_date=$row['job_completed_date'];
			$status=$row['status'];
			
		$Site="SELECT * FROM `Site` where id='$site'";
            $Site_det=mysqli_query($conn,$Site);
			$response = array();
				$response1 = array();
       $row2 = mysqli_fetch_assoc($Site_det);
           
                $Site_id=$row2['id'];
                $Site_name=$row2['name'];
				
				
				$Plot="SELECT * FROM `Plot` where id='$plot'";
				
				
            $Plo_det=mysqli_query($conn,$Plot);
		//	$response = array();
       $row3 = mysqli_fetch_assoc($Plo_det);
           
                $Plot_id=$row3['id'];
                
                $Plot_name=$row3['name'];
                $job_id=$row['job_id']; 
                $Plot_name=$Plot_name; 
				$Site_name=$Site_name; 
				$location=$location; 
			    $work_description=$row['work_description']; 
                $status=$row['status']; 
			    $card_end_date=$row['job_completed_date']; 
          
				if($Plot_name)
				{
				    $Plot_name1=$Plot_name;  
				    
				}
				else
				{
				     $Plot_name1='';    
				}
				
              
			$jobcard_det="select * from jobcard_det where job_id='".$row['job_id']."' ";

	    $jobcard_det_rs=mysqli_query($conn,$jobcard_det);
	 while($row4 = mysqli_fetch_array($jobcard_det_rs))
  {
		 
		
		    $categoryid=$row4['categories'];
	  
	    	$Product_category="select * from  job_types where id='".$categoryid."' ";
	    	
	    	
	    	
	        $Product_category1=mysqli_query($conn,$Product_category);
			 while($row5 = mysqli_fetch_assoc($Product_category1))
  {
   
    $product_name=$row5['name']; 
 }


			 array_push($response1, 
           	$product_name);  
				
              
        
        }
		
		
				$output=array( "code" => "200","job_id" =>$job_id,"Plot_name" =>$Plot_name1,"Site_name" =>$Site_name,
				"location" =>$location,"work_description" =>$work_description,"status" =>$status,"card_end_date" =>$card_end_date,"category"=>$response1);
				print_r(json_encode($output, true));    
				
				
	
	}
	}	
	

	function category_merterial_request()
	{
	  
 require_once 'db.php';

  if ($conn->connect_error) 
  {
  die("Connection failed: " . $conn->connect_error);
   }  
	    
	 
			   	$category="SELECT * FROM `job_types`";
			   	
			   	$category_det=mysqli_query($conn,$category);
				
					 $response_category = array();
        while( $row1 = mysqli_fetch_assoc($category_det) ){
            array_push($response_category, 
            array(
                'category_id'=>$row1['id'], 
                'category_name'=>$row1['name'], 
                
                ) 
            );
        }
			
	$output=array( "code" => "200","category"=>$response_category);
	print_r(json_encode($output, true));  
	    
	}
	
	
	
function category_card_id_request()
	{
	  
 require_once 'db.php';

  if ($conn->connect_error) 
  {
  die("Connection failed: " . $conn->connect_error);
   }  
	        $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);

		
		if(isset($event_json['id']) )
		{
		
		
			$id=strip_tags($event_json['id']);
	 
			   	$category="SELECT * FROM `jobcard_det` where job_id='$id'";
			   	
			   	$category_det=mysqli_query($conn,$category);
				
					 $response_category = array();
        while( $row1 = mysqli_fetch_array($category_det) ){
            
            
		 $category_id=$row1['categories']; 
		 
		
	  
	    	$Product_category="select * from  job_types where id='".$category_id."' ";
	    	
	    	
	    	
	        $Product_category1=mysqli_query($conn,$Product_category);
			 while($row5 = mysqli_fetch_assoc($Product_category1))
  {
   $product_id=$row5['id']; 
    $product_name=$row5['name']; 
 }


			
		
            array_push($response_category, 
            array(
                'category_id'=>$product_id, 
                'category_name'=>$product_name, 
                
                ) 
            );
        }
			
	$output=array( "code" => "200","category"=>$response_category);
	print_r(json_encode($output, true));  
	    
	}
	}
		
function work_shedule_request()
	{
	    
	    
	require_once 'db.php';
	    
$json = file_get_contents('php://input');
$data = json_decode($json);	   

$start_date=$data->start_date;
$end_date=$data->end_date;

$jobcard_id=$data->jobcard_id;
$worker_id=$data->worker_id;
 $regular=$data->regular;
$over_time1=$data->over_time1;
$over_time2=$data->over_time2;
$status="active";
if($regular)
{
 $regular_t= $regular ;
}
else
{
$regular_t='0';    
}

if($over_time1)
{
 $over_time_t=$over_time1; 
}
else
{
  $over_time_t='0';   
}

if($over_time2)
{
  $over_time_t2=$over_time2;   
}
else
{
 $over_time_t2='0';     
}


$Date1 = $start_date;
$Date2 = $end_date;
  
// Declare an empty array
$array = array();
  
// Use strtotime function
$Variable1 = strtotime($Date1);
$Variable2 = strtotime($Date2);
  

for ($currentDate = $Variable1; $currentDate <= $Variable2; $currentDate += (86400)) 
{
                                      
$Store = date('Y-m-d', $currentDate);
$array[] = $Store;
$Count = count($array);

$query1 = "SELECT * FROM work_shedule_master INNER JOIN work_shedule_detail ON work_shedule_detail.w_s_m_id = work_shedule_master.id
    where work_shedule_master.jobcard_id='".$jobcard_id."' and  work_shedule_detail.date='".$Store."' and  work_shedule_detail.worker_id='".$worker_id."' ";
  
    

    $stmt1 = $conn->query($query1);
    
    
    
    
$res = mysqli_num_rows($stmt1);

}
  
    $rownew = mysqli_fetch_assoc($stmt1);
  
//echo($res);

    
     if($res!='0')
     {
           
     $output=array( "code" => "201","msg"=>"Work schedule exist for selected dates & jobcard");
	print_r(json_encode($output, true));      
         
     }

 
else
{


if($start_date!='' and $end_date!='')
{
   $sql="INSERT INTO `work_shedule_master`(`jobcard_id`, `worker_id`,`from_date`,`to_date`) VALUES 
   ('$jobcard_id','$worker_id','$start_date','$end_date')";
   

   
  mysqli_query($conn,$sql);
   
  
 
   $query = "SELECT id from work_shedule_master order by `id` DESC LIMIT 1";
    $stmt = $conn->query($query);
     if ($row = mysqli_fetch_assoc($stmt)) 
     {
 $jc_sh_id= $row['id'];
$Date1 = $start_date;
$Date2 = $end_date;
  
// Declare an empty array
$array = array();
  
// Use strtotime function
$Variable1 = strtotime($Date1);
$Variable2 = strtotime($Date2);
  

for ($currentDate = $Variable1; $currentDate <= $Variable2; $currentDate += (86400)) 
{
                                      
$Store = date('Y-m-d', $currentDate);
$array[] = $Store;
$Count = count($array);

}
  
 for($i = 0; $i < $Count; $i++)
        {

 $date = $array[$i];
 $sql2="INSERT INTO `work_shedule_detail`(`w_s_m_id`, `date`, `work_hours`, `over_time1`, `over_time2`,`worker_id`,`status`)
     VALUES ('$jc_sh_id','$date','$regular_t','$over_time_t','$over_time_t2','$worker_id','$status')";
   mysqli_query($conn,$sql2); 

}
	$output=array( "code" => "200","msg"=>"Schedule Created Successfully");
	print_r(json_encode($output, true));  	
     }
}
    else
    {
     $output=array( "code" => "201","msg"=>"Error");
	print_r(json_encode($output, true));  	   
    }
     
}
		
	}
	

	
	function work_shedule_details()
	{ 
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		$id=strip_tags($event_json['id']);
// 		$fdrl=strip_tags($event_json['folder_name']);
		$response = array();
		
	$work_shedule="SELECT * FROM work_shedule_detail where w_s_m_id='".$id."'ORDER BY `work_shedule_detail`.`date` ASC ";
   	$work_shedule_rs=mysqli_query($conn,$work_shedule);
	     $response = array();	

	while($row = mysqli_fetch_array($work_shedule_rs))
  {
 
   
    $fdate=date_create($row['date']);

		$tdate= date_format($fdate,"d/m/Y");
		
		
       array_push($response, 
          array( 
           'date' => $tdate,
		   'work_hours' =>$row['work_hours'],
			'over_time1' =>$row['over_time1'],
			'over_time2' =>$row['over_time2'],
				'status' =>$row['status'],
				'id' =>$row['id']	
				)
			);  
  }
      	$output=array( "code" => "200","work_shedule_details"=>$response);
				print_r(json_encode($output, true));    
	}
	}
	
	
	
	
	
	function work_shedule_employees()
	{
	    
	    
require_once 'db.php';
	    
$json = file_get_contents('php://input');
$data = json_decode($json);	   

$start_date=$data->date;
$end_date=$data->date;

$jobcard_id=$data->jobcard_id;
$worker_id=$data->worker_id;
 $regular=$data->regular;
$over_time1=$data->over_time1;
$over_time2=$data->over_time2;
$status="active";
if($regular)
{
 $regular_t= $regular ;
}
else
{
$regular_t='0';    
}

if($over_time1)
{
 $over_time_t=$over_time1; 
}
else
{
  $over_time_t='0';   
}

if($over_time2)
{
  $over_time_t2=$over_time2;   
}
else
{
 $over_time_t2='0';     
}


   
    $query1 = "SELECT * FROM work_shedule_master INNER JOIN work_shedule_detail ON work_shedule_detail.w_s_m_id = work_shedule_master.id
    where work_shedule_master.jobcard_id='".$jobcard_id."' and  `work_shedule_master`.`worker_id`='".$worker_id."' and   work_shedule_detail.work_hours<='8' and work_shedule_detail.date='".$start_date."'";
   

    $stmt1 = $conn->query($query1);
$res = mysqli_num_rows($stmt1);

    
     if($res!='0')
     {
       
         
     $output=array( "code" => "201","msg"=>"Employee is already scheduled on same jobcard and date");
	print_r(json_encode($output, true));      
         
     }
	else
	{
	   
//echo("hello");
   
    
    if($start_date!='' and $end_date!='')
{
    
  //  echo("hello");
    
   $sql="INSERT INTO `work_shedule_master`(`jobcard_id`, `worker_id`,`from_date`,`to_date`) VALUES 
   ('$jobcard_id','$worker_id','$start_date','$end_date')";
  // echo($sql);
    
   
   mysqli_query($conn,$sql);
  
 
   $query = "SELECT id from work_shedule_master order by `id` DESC LIMIT 1";
    $stmt = $conn->query($query);
     if ($row = mysqli_fetch_assoc($stmt)) 
     {
         
         
         
 $jc_sh_id= $row['id'];
$Date1 = $data->date;

$Date2 = $end_date;
  
// Declare an empty array
$array = array();
  
// Use strtotime function
$Variable1 = strtotime($Date1);
$Variable2 = strtotime($Date2);
  

for ($currentDate = $Variable1; $currentDate <= $Variable2; 
                                $currentDate += (86400)) {
                                      
$Store = date('Y-m-d', $currentDate);
$array[] = $Store;
$Count = count($array);
}
  
 for($i = 0; $i < $Count; $i++)
        {

 $date = $array[$i];
 
     $sql2="INSERT INTO `work_shedule_detail`(`w_s_m_id`, `date`, `work_hours`, `over_time1`, `over_time2`,`worker_id`,`status`)
     VALUES ('$jc_sh_id','$Date1','$regular_t','$over_time_t','$over_time_t2','$worker_id','$status')";
     
  
      mysqli_query($conn,$sql2); 

}


	$output=array( "code" => "200","msg"=>"Schedule Created Successfully");
	print_r(json_encode($output, true));  	
     }
}
	
	else
	{
	 	$output=array( "code" => "201","msg"=>"Error");
	print_r(json_encode($output, true));     	
}
	
	    
	}	    
	    
	}
	
	function work_shedule_list()
	{ 
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  

$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		$id=strip_tags($event_json['id']);
// 		$fdrl=strip_tags($event_json['folder_name']);
		$response = array();

	


	$job_card_work_shedule="SELECT * FROM work_shedule_master where jobcard_id='$id' ORDER BY `work_shedule_master`.`id` DESC ";
	
//	echo($job_card_work_shedule);
   	$job_card_shedule=mysqli_query($conn,$job_card_work_shedule);
	
		 $response = array();		 
	while($row = mysqli_fetch_array($job_card_shedule))
  
 {

  $worker_id=$row['worker_id'];
  $w_s_m_id=$row['id'];
  
  
  		$worker_s_d1="SELECT * FROM `work_shedule_detail` where w_s_m_id ='$w_s_m_id'";
  	
        $worker_det_sr1=mysqli_query($conn,$worker_s_d1);
	
       $row31 = mysqli_fetch_assoc($worker_det_sr1);
      
  
  
  		
		$worker="SELECT * FROM `employees` where id='$worker_id'";
        $worker_det=mysqli_query($conn,$worker);
	
       $row2 = mysqli_fetch_assoc($worker_det);
        $wname=$row2['name'];
				 $from_date=date_create($row['from_date']);
	$from_date1=date_format($from_date,"d/m");
		 $to_date=date_create($row['to_date']);
		$to_date1= date_format($to_date,"d/m/Y");
       array_push($response, 
       array( 
          
          'from_date'=> $from_date1,
           'to_date'=> $to_date1,
           'jobcard_id'=>  $row['jobcard_id'],
		   'w_name'=> $wname,
		    'work_hours'=> $row31['work_hours'],
			'over_time1'=> $row31['over_time1'],
			'over_time2'=> $row31['over_time2'],
			'id'=> $row31['w_s_m_id']
		   ));   }
  
				$output=array( "code" => "200","work_shedule"=>$response);
				print_r(json_encode($output, true));    
	
		}	

}

 function shedule_emoployee_list()
	{ 
	    
	//echo("hello");
	    
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  

	
	$start_date=date("Y-m-d");
	
   $end_date=(date('Y-m-d',strtotime('+30 days',strtotime($start_date)))) . PHP_EOL;
	 $response = array();	
 
  		$worker_s_d="SELECT DISTINCT (worker_id) FROM `work_shedule_detail` WHERE `date` between '$start_date' AND '$end_date'";
  		
  	
  	
        $worker_det_sr=mysqli_query($conn,$worker_s_d);
	
    while($row = $row3 = mysqli_fetch_array($worker_det_sr))
  {
    
      
        $worker_id=$row3['worker_id'];
        
        
        $worker1="SELECT * FROM `work_shedule_detail` where worker_id='$worker_id' and date>='$start_date' ORDER BY `work_shedule_detail`.`date` ASC";
        $worker_det1=mysqli_query($conn,$worker1);
	    $row21 = mysqli_fetch_assoc($worker_det1);
        // $wname=$row21['name'];
        
        
        
		$worker="SELECT * FROM `employees` where id='$worker_id'";
        $worker_det=mysqli_query($conn,$worker);
	    $row2 = mysqli_fetch_assoc($worker_det);
        $wname=$row2['name'];
				
	
       array_push($response, 
             array(  "date"=>$row21['date'],
            "empid"=>$worker_id,
           "empname"=>$wname ));  
  }
      
				$output=array( "code" => "200","sheduled_employess"=>$response);
				print_r(json_encode($output, true));    
	}		
	
 function shedule_emoployees_jobcard_list()
	{ 
	   
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  

	
$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		$id=strip_tags($event_json['id']);

		$response = array();
		$from_date=date("Y-m-d");
		
	$work_shedule_shedule="SELECT  * FROM work_shedule_master where worker_id='".$id."' and `to_date`>='".$from_date."' ORDER BY `work_shedule_master`.`from_date` DESC";
	//echo($work_shedule_shedule);

   	$job_work_shedule=mysqli_query($conn,$work_shedule_shedule);
	
	
	while($row = mysqli_fetch_array($job_work_shedule))
  {
  

  $worker_id=$row['worker_id'];
  
  
 
  $w_s_m_id=$row['id'];

  		$worker_s_d="SELECT * FROM `work_shedule_detail` where w_s_m_id ='$w_s_m_id' and `date`>='$from_date' ORDER BY `work_shedule_detail`.`date` ASC";
  	
//   	echo($worker_s_d);
        $worker_det_sr=mysqli_query($conn,$worker_s_d);
	
       $row3 = mysqli_fetch_assoc($worker_det_sr);
       
      		$worker="SELECT * FROM `employees` where id='$worker_id'";
        $worker_det=mysqli_query($conn,$worker);
	
       $row2 = mysqli_fetch_assoc($worker_det);
        $wname=$row2['name'];
				
	
       array_push($response, 
        array( 
           "date"=>$row3['date'],
            "jobcard_id"=>$row['jobcard_id'],
		  // "worker_name"=>$wname,
		   "work_hours"=> $row3['work_hours'],
			"over_time1"=>$row3['over_time1'],
		   "over_time2"=>	$row3['over_time2'],
		   	"over_time1"=>$row3['over_time1'],
		   "remove_id"=>$w_s_m_id,
		   ));   }
      
				$output=array( "code" => "200","work_shedule"=>$response);
				print_r(json_encode($output, true));    
	}
	}
	
	function remove_schedule()
	{
	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
			
	
			
			$remove_schedule="DELETE FROM `work_shedule_master` WHERE `id`='".$id."'";
			mysqli_query($conn,$remove_schedule);
			
			
			$remove_schedule_detail="DELETE FROM `work_shedule_detail` WHERE `w_s_m_id`='".$id."'";
		if(mysqli_query($conn,$remove_schedule_detail))
		{
		 
				$value= "Work schedule Remove Successfully";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));
			}	
			else
			{
			   
			    
			    $array_out1="Error in Remove";
			    
    		
        		
        		$output=array( "code" => "201", "msg" => $array_out1);
        		print_r(json_encode($output, true));
			}
		    
		    
		    }	
	}
			
	function update_schedule_details()
	{
	  
 require_once 'db.php';
	    
$json = file_get_contents('php://input');
$data = json_decode($json);	   



$product_data=array();
$product_data=$data->{work_shedule_details};
if($product_data)
{
	   for ($i=0; $i < count($product_data); $i++) { 	   
		   
		    $id=$product_data[$i]->id;
		    $work_hours=$product_data[$i]->work_hours;
		    $over_time1=$product_data[$i]->over_time1;
		    $over_time2=$product_data[$i]->over_time2;
		    $status=$product_data[$i]->status;
		    
		    
      	      
      	      
      	      
			
			$update_schedule_details="UPDATE `work_shedule_detail` SET 
			`work_hours`='$work_hours',
			`over_time1`='$over_time1',
			`over_time2`='$over_time2',
			`status`='$status' WHERE `id`='".$id."'";
			
		
		
			mysqli_query($conn,$update_schedule_details);
			
	   }			 
		 
				$value= "Work schedule Update Successfully";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));
			}
			else
			{
			 	$value= "Work schedule not Update ";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));   
			}
			
		}	
	   
		    
		    	
			
	function shedule_emoployee_date_list()
	{ 
	    
	//echo("hello");
	    
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['date']))
		{
		$date=strip_tags($event_json['date']);
		$jid=strip_tags($event_json['id']);

	 $response = array();	
 
  		$worker_s_d="SELECT * FROM work_shedule_master INNER JOIN work_shedule_detail ON work_shedule_detail.w_s_m_id = work_shedule_master.id
        where work_shedule_detail.date='".$date."' and work_shedule_master.jobcard_id='".$jid."' ";
  		

  	
        $worker_det_sr=mysqli_query($conn,$worker_s_d);
	
    while($row = $row3 = mysqli_fetch_array($worker_det_sr))
  {
    
      
        $worker_id=$row3['worker_id'];
        
        
        $worker1="SELECT * FROM `work_shedule_detail` where worker_id='$worker_id' ORDER BY `work_shedule_detail`.`date` ASC";
        $worker_det1=mysqli_query($conn,$worker1);
	    $row21 = mysqli_fetch_assoc($worker_det1);
        // $wname=$row21['name'];
        
        
        
		$worker="SELECT * FROM `employees` where id='$worker_id'";
        $worker_det=mysqli_query($conn,$worker);
	    $row2 = mysqli_fetch_assoc($worker_det);
        $wname=$row2['name'];
				
	
	
	
       array_push($response, 
             array( "date"=>$row21['date'],
            "empid"=>$worker_id,
           "empname"=>$wname,
       "work_hours"=>$row21['work_hours'],
           "over_time1"=>$row21['over_time1'],
		     "over_time2"=>$row21['over_time2'],
           "id"=>$row21['id'],

		   ));  
  }
      
				$output=array( "code" => "200","scheduled_employess_date"=>$response);
				print_r(json_encode($output, true));    
	}
	}
	
 function update_employee_schedule_details()
	{
	  
require_once 'db.php';

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  
	    
	    $input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
			  $w_id=strip_tags($event_json['w_id']);
				$date=strip_tags($event_json['date']);
		    	$hours=strip_tags($event_json['hours']);
				$over_t1=strip_tags($event_json['over_t1']);
			   $over_t2=strip_tags($event_json['over_t2']);
      	      $value='active';
			  
			if($date)
			{
			    
	 $query1 = "SELECT * FROM work_shedule_master INNER JOIN work_shedule_detail ON work_shedule_detail.w_s_m_id = work_shedule_master.id
    where work_shedule_master.worker_id='".$w_id."' and  work_shedule_detail.date='".$date."'";
    
 
     

    $stmt1 = $conn->query($query1);
$res = mysqli_num_rows($stmt1);

 $worker_det_sr=mysqli_query($conn,$query1);
 
      $row21 = mysqli_fetch_assoc($worker_det_sr);
     
    $startdate = $row21['from_date'];
    $enddate = $row21['to_date'];
    $jobcard_id =$row21['jobcard_id'];

    if($startdate <= $date && $date <= $enddate) {
        
        
        
    $output=array( "code" => "201","msg"=>"Employee is already scheduled on same jobcard and date");
	print_r(json_encode($output, true));
	
    }
    else{
             
				 $update_schedule_mster="INSERT INTO `work_shedule_master`(`jobcard_id`, `worker_id`, `from_date`, `to_date`) VALUES('$jobcard_id','$w_id','$date','$date')";   
				
				    mysqli_query($conn,$update_schedule_mster);
				    
				    
	 $querynew = "SELECT id from work_shedule_master order by `id` DESC LIMIT 1";
    $stmtnew = $conn->query($querynew);
    $rownew = mysqli_fetch_assoc($stmtnew); 
     
 $last_id= $rownew['id'];

				    
				   $update_schedule_details="UPDATE `work_shedule_detail` SET 
				   `w_s_m_id`='$last_id',
			`date`='$date',
			`work_hours`='$hours',
			`over_time1`='$over_t1',
			`over_time2`='$over_t2',
			`status`='$value' WHERE `id`='".$id."'";

			if(mysqli_query($conn,$update_schedule_details))
				{
				     
		 
				$value= "Work schedule Update Successfully";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));
			}
			
			
		
	    
	}
	}
		    } 
		    }		
	
	function work_schedule_list_today()
	{ 
require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  

$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		$id=strip_tags($event_json['id']);
// 		$fdrl=strip_tags($event_json['folder_name']);
		$response = array();

	

	$job_card_work_shedule="SELECT * FROM work_shedule_master where jobcard_id='$id' ORDER BY `work_shedule_master`.`id` DESC ";


//	echo($job_card_work_shedule);
   	$job_card_shedule=mysqli_query($conn,$job_card_work_shedule);
	
		 $response = array();		 
	while($row = mysqli_fetch_array($job_card_shedule))
  
 {

  $worker_id=$row['worker_id'];
  $w_s_m_id=$row['id'];
  	$start_date=date("Y-m-d");
  
  		$worker_s_d1="SELECT * FROM `work_shedule_detail` where w_s_m_id ='$w_s_m_id' and date='$start_date'";
  	
        $worker_det_sr1=mysqli_query($conn,$worker_s_d1);
	
       $row31 = mysqli_fetch_assoc($worker_det_sr1);
      
  if($row31)
  {
  
  		
		$worker="SELECT * FROM `employees` where id='$worker_id'";
        $worker_det=mysqli_query($conn,$worker);
	
       $row2 = mysqli_fetch_assoc($worker_det);
        $wname=$row2['name'];
				 $from_date=date_create($row['from_date']);
	$from_date1=date_format($from_date,"d/m");
		 $to_date=date_create($row31['date']);
		$to_date1= date_format($to_date,"d/m/Y");
       array_push($response, 
       array( 
          
         
           'date'=> $to_date1,
           'jobcard_id'=>  $row['jobcard_id'],
		   'w_name'=> $wname,
		    'work_hours'=> $row31['work_hours'],
			'over_time1'=> $row31['over_time1'],
			'over_time2'=> $row31['over_time2'],
			'id'=> $row31['id'],
				'remove_id'=> $w_s_m_id
		   ));  
		   }
  
 }
				$output=array( "code" => "200","work_shedule"=>$response);
				print_r(json_encode($output, true));    
 
		}
 else
 {
	 
	 $array_out="No schedules arranged today";
	$output=array( "code" => "201","msg"=>$array_out);
				print_r(json_encode($output, true));    	 
	 
	 
 }
 
 
		}
		
		
	function update_schedule_single()
	{
	  
 	require_once 'db.php';
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}  

$input = @file_get_contents("php://input");
	    $event_json = json_decode($input,true);
		if(isset($event_json['id']))
		{
		    $id=strip_tags($event_json['id']);
$work_hours=strip_tags($event_json['work_hours']);
$over_time1=strip_tags($event_json['over_time1']);
$over_time2=strip_tags($event_json['over_time2']);
$status=strip_tags($event_json['status']);

   
		 
			$update_schedule_details="UPDATE `work_shedule_detail` SET 
			`work_hours`='$work_hours',
			`over_time1`='$over_time1',
			`over_time2`='$over_time2',
			`status`='$status' WHERE `id`='".$id."'";
			
	
			mysqli_query($conn,$update_schedule_details);
			
	   		 
		 
				$value= "Work schedule Update Successfully";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));
			}
			else
			{
			 	$value= "Work schedule not Update ";
				$output=array( "code" => "200","msg"=>$value);
				print_r(json_encode($output, true));   
			}
			
		}		
		
	

	?>