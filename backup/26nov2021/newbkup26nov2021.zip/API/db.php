

<?php
 define('HOST','localhost');         //hostname
 define('USER','beta123_interco');     //username
 define('PASS','%a$X#WqzOPU8');        //user password
 define('DB','beta123_interco');  //database name
 
$conn = new MySQLi(HOST,USER,PASS,DB) or die('Unable to Connect');

?>