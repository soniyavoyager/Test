

<?php


if ($_SERVER['REQUEST_METHOD'] == 'POST' )
{
 
 require_once 'db.php';
 
 $json = file_get_contents('php://input');
//  $data = json_decode($json);
 
$jobcard_id =  $_POST['jobcard_id'];
$folder_name =  $_POST['folder_name'];
$job_card_date =  date("Y/m/d");

   $sql="INSERT INTO `job_card_img_mst`(`jobcard_id`, `folder_name`, `job_card_date`) VALUES 
   ('$jobcard_id','$folder_name','$job_card_date')";
    
   
   mysqli_query($conn,$sql);
  
 
   $query = "SELECT id from job_card_img_mst order by `id` DESC LIMIT 1";
    $stmt = $conn->query($query);
     if ($row = mysqli_fetch_assoc($stmt)) 
     {
            $jc_im_id= $row['id'];
        }
 

  $images = array();
  $ImageCount = count($_FILES['image']['name']);
  

  
        for($i = 0; $i < $ImageCount; $i++)
        {
            $_FILES['file']['name']       = $_FILES['image']['name'][$i];
            $_FILES['file']['type']       = $_FILES['image']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['image']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['image']['error'][$i];
            $_FILES['file']['size']       = $_FILES['image']['size'][$i];
            
     
            $uploadPath = '../material_img/';
     
  $target_file_name = $uploadPath .$_FILES['file']['name'];
  
  $pic='https://intercol.betaholder.com/material_img/'.$_FILES['file']['name'];
  if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file_name)) 
   {
     
     $sql2="INSERT INTO `job_card_img_det`( `jc_im_id`, `image`) VALUES ('$jc_im_id','$pic')";
     mysqli_query($conn,$sql2); 
 
  } 
   }
   	$response='Jobcard Image Upload Sucessfully';
	$output=array( "code" => "200","msg"=>$response);
	print_r(json_encode($output, true));  
			
   
   } 
    
  

?>
	